/*
Copyright © 2025 PRAS
*/
package main

import "github.com/PRASSamin/prasmoid/src/cmd"

func main() {
	cmd.Execute()
}
