/*
Copyright 2025 PRAS
Development commands for Prasmoid
*/
package main

import (
	"github.com/PRASSamin/prasmoid/dev/cmd"
)

func main() {
	cmd.Execute()
}
