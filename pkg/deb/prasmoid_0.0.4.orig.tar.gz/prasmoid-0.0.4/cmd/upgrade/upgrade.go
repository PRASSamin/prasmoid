/*
Copyright 2025 PRAS

This command implements the Prasmoid CLI update functionality using a remote update script. Instead of embedding complex update logic directly in the Go code, which would increase the binary size by approximately 2MB, this approach leverages a lightweight shell script hosted on GitHub. This design choice ensures that Prasmoid remains lightweight while maintaining robust update capabilities.
*/
package upgrade

import (
	"fmt"
	"os"
	"strings"

	"github.com/AlecAivazis/survey/v2"
	"github.com/PRASSamin/prasmoid/consts"
	"github.com/fatih/color"
	"github.com/spf13/cobra"

	root "github.com/PRASSamin/prasmoid/cmd"
)

func init() {
	root.RootCmd.AddCommand(upgradeCmd)
}

var upgradeCmd = &cobra.Command{
	Use:   "upgrade",
	Short: "Upgrade to latest version of Prasmoid CLI.",
	Run: func(cmd *cobra.Command, args []string) {
		if err := checkRoot(); err != nil {
			fmt.Println(color.RedString(err.Error()))
			return
		}

		if !utilsIsPackageInstalled(consts.CurlPackageName["binary"]) {
			pm, _ := utilsDetectPackageManager()
			confirmPrompt := &survey.Confirm{
				Message: "curl is not installed. Do you want to install it first?",
				Default: true,
			}
			if err := surveyAskOne(confirmPrompt, &confirmInstallation); err != nil {
				fmt.Println(color.RedString("Failed to ask for curl installation: %v", err))
				return
			}

			if confirmInstallation {
				if err := utilsInstallPackage(pm, consts.CurlPackageName["binary"], consts.CurlPackageName); err != nil {
					fmt.Println(color.RedString("Failed to install curl:", err))
					return
				}
			} else {
				fmt.Println("Operation cancelled.")
				return
			}
		}

		exePath, err := osExecutable()
		if err != nil {
			fmt.Println(color.RedString("Failed to get current executable path: %v", err))
			return
		}

		cmdStr := fmt.Sprintf("curl -sSL %s | bash -s %s", scriptURL, exePath)

		command := execCommand("bash", "-c", cmdStr)
		command.Stdout = os.Stdout
		command.Stderr = os.Stderr

		if err := command.Run(); err != nil {
			fmt.Println(color.RedString("Update failed: %v", err))
		}

		if err := osRemove(rootGetCacheFilePath()); err != nil {
			// Log the error, but don't fail the upgrade process
			fmt.Println(color.YellowString("Warning: Failed to remove update cache file: %v\n", err))
		}
	},
}

var checkRoot = func() error {
	currentUser, err := userCurrent()
	if err != nil {
		return fmt.Errorf("failed to get current user: %v", err)
	}

	if currentUser.Uid != "0" {
		return fmt.Errorf("the requested operation requires superuser privileges. use `sudo %s`", strings.Join(os.Args[0:], " "))
	}
	return nil
}
