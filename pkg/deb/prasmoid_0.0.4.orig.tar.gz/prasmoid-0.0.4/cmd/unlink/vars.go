package unlink

import (
	"os"

	"github.com/PRASSamin/prasmoid/utils"
)

var (
	utilsGetDevDest = utils.GetDevDest
	osRemoveAll     = os.RemoveAll
)
