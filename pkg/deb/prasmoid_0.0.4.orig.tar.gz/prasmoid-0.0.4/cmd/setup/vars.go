package setup

import (
	"github.com/PRASSamin/prasmoid/utils"
)

var (
	utilsInstallDependencies = utils.InstallDependencies
)
